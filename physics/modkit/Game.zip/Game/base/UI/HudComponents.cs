using Physics;

namespace UI
{
    ///<summary>
    ///This contains the base HUD Components, the Hud.cs contains gamemode specific huds (for example, killfeed, teams, etc)
    ///</summary>
    [ClassLibrary] 
    class Vitals : HudComponents
    {

        public double Health {get; set;}

        public double Armor {get; set;}

        public override void OnTick() {
            if(Physics.Player.Local == null)
            return;

            Health = Physics.Player.Local.Health;
            Armor = Physics.Player.Local.Armor;
        }
    }
}

