<template>
    <div class="vitals">

        <div class="health">
            <icon type="add box"></icon> {{Health}}
        </div>

        <div class="armor" v-bind:class="{none : Armor <= 0}">
            <icon type="security"></icon> {{Armor}}
        </div>
        
</template>



