<template>
    <div id="FriendList">
        <div id="FriendContainer" v-for="friend in orderedFriends">
            <div class="AvatarContainer">
                <MenuSystem-SteamAvatar :steamid="friend.SteamId" size="40"></MenuSystem-SteamAvatar>
            </div>
            <div class="NameAndStatusContainer">
                <a>{{friend.Name}}</a>
                <a class="Status">{{friendStatus(friend)}}</a>
            </div>
        </div>
    </div>
</template>

<script>
    module.exports = {
        computed: {
            orderedFriends: function () {
                return _.orderBy(this.Friends, 'IsPlaying').reverse();
            }
        },
        friendStatus: function (friend) {
            return friend.IsPlaying ? (friend.IsPlayingThisGame ? 'Ingame' : 'Playing something else') : 'online';
        }
    }
</script>

<style lang="less">
    #FriendContainer {
        padding: 4px 0px 4px 0px;
        display: flex;
        opacity: 0.7;
        transition: opacity ease-in-out 0.125s;
    }
        #FriendContainer:hover {
            opacity: 1.0;
        }
    .AvatarContainer {
        background-color: rgba(0, 0, 0, 0.4);
        padding: 2px;
        display: inline-block
    }
    .NameAndStatusContainer {
        flex: 1;
        display: flex;
        justify-content: center;
        flex-direction: column;
        padding-left: 10px;
        font-size: 15px;
    }
        .NameAndStatusContainer .Status {
            opacity: 0.7;
            font-size: 13px
        }
</style>