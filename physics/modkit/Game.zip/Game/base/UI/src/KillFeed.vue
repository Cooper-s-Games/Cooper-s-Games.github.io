<template>
    <tr v-for="player in OrderBy(PlayerList, 'score', 'desc')" :class="{LocalPlayer}>
        
        </tr>
</template>