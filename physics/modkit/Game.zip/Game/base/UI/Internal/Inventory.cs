using Physics;
using Physics.UI;
using System.Collections.Generic;
using System.Linq;


public class InventoryBar : Panel, IClientInput
{
	List<InventoryColumn> columns = new();
	List<BaseWeapon> Weapons = new();

	public bool IsOpen;
	BaseWeapon SelectedWeapon;

	public InventoryBar()
	{
		StyleSheet = StyleSheet.FromFile( "/UI/Internal/Inventory.scss" );

		for ( int i=0; i<6; i++ )
		{
			var icon = new InventoryColumn( i, this );
			columns.Add( icon );
		}
	}

	public override void Tick()
	{
		base.Tick();

		SetClass( "active", IsOpen );

		var player = Player.Local;
		if ( player == null ) return;

		Weapons.Clear();
		Weapons.AddRange( player.Children.Select( x => x as BaseWeapon ).Where( x => x.IsValid() && x.IsUsable() ) );

		foreach ( var weapon in Weapons )
		{
			columns[weapon.Bucket].UpdateWeapon( weapon );
		}
	}


	public void ProcessClientInput( ClientInput input )
	{
		bool wantOpen = IsOpen;
		wantOpen = wantOpen || input.MouseWheel != 0;
		wantOpen = wantOpen || input.Pressed( InputButton.Slot1 );
		wantOpen = wantOpen || input.Pressed( InputButton.Slot2 );
		wantOpen = wantOpen || input.Pressed( InputButton.Slot3 );
		wantOpen = wantOpen || input.Pressed( InputButton.Slot4 );

		if ( Weapons.Count == 0 )
		{
			IsOpen = false;
			return;
		}

		// We're not open, but we want to be
		if ( IsOpen != wantOpen )
		{
			SelectedWeapon = Player.Local.ActiveChild as BaseDmWeapon;
			IsOpen = true;
		}

		
		if ( !IsOpen ) return;

		
		if ( input.Down( InputButton.Attack1 ) )
		{
			input.SuppressButton( InputButton.Attack1 );
			input.ActiveChild = SelectedWeapon;
			IsOpen = false;
			Sound.FromScreen( "sound/ui/pop.wav" );
			return;
		}

		// get our current index
		var oldSelected = SelectedWeapon;
		int SelectedIndex = Weapons.IndexOf( SelectedWeapon );
		SelectedIndex = SlotPressInput( input, SelectedIndex );

		

		SelectedWeapon = Weapons[SelectedIndex];

		for ( int i = 0; i < 6; i++ )
		{
			columns[i].TickSelection( SelectedWeapon );
		}

		input.MouseWheel = 0;

		if ( oldSelected  != SelectedWeapon )
		{
			
		}
	}

	int SlotPressInput( ClientInput input, int SelectedIndex )
	{
		var columninput = 0;

		if ( input.Pressed( InputButton.Slot1 ) ) columninput = 0;
		if ( input.Pressed( InputButton.Slot2 ) ) columninput = 1;
		if ( input.Pressed( InputButton.Slot3 ) ) columninput = 2;
		if ( input.Pressed( InputButton.Slot4 ) ) columninput = 3;
		if ( input.Pressed( InputButton.Slot5 ) ) columninput = 4;

		if ( columninput == 0 ) return SelectedIndex;

		if ( SelectedWeapon.IsValid() && SelectedWeapon.Bucket == columninput )
		{
			return NextInBucket();
		}


		var firstOfColumn = Weapons.Where( x => x.Bucket == columninput ).OrderBy( x => x.BucketWeight ).FirstOrDefault();
		if ( firstOfColumn  == null )
		{
			// play sound
			return SelectedIndex;
		}

		return Weapons.IndexOf( firstOfColumn );
	}

	int NextInBucket()
	{
		Assert.NotNull( SelectedWeapon );

		BaseWeapon first = null;
		BaseWeapon prev = null;
		foreach ( var weapon in Weapons.Where( x => x.Bucket == SelectedWeapon.Bucket ).OrderBy( x => x.BucketWeight ) )
		{
			if ( first == null ) first = weapon;
			if ( prev == SelectedWeapon ) return Weapons.IndexOf( weapon );
			prev = weapon;
		}

		return Weapons.IndexOf( first );
	}
}