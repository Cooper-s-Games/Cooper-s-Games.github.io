using Physics;

namespace Physics.Effects
{
    [ClassLibrary]
    public class BlockDebrisEffect : Effect
    {
        protected override void Load()
        {
            new ParticleEmitter(this)
            {
                Material = Material.Library.Get("particles/block.mat"),

                StartRotation = 0,
                RotationRate = 0,

                SpawnRadius = 100,
                SpawnRadialVelocity = 250,
                SpawnSize = 0.125,

                LifeScale = Curve3.Linear(1.0, 0.0),
                AlphaScaleOverLife = Curve.Linear(1.0, 0.0),
                LifeTime = 2.0,

                Sort = ParticleSort.ProjectedDistance,
                Drag = 1,

                Model = Model.Library.Get("models/block.fbx"),
                ModelCastShadows = true,
                OverrideModelMaterial = true,

                EnableCollisions = true,
                CollisionMax = 5,
                OnCollisionMax = ParticleCollisionComplete.Kill,
                CollisionDamp = Curve3.Random(0.5, 1.0),

                SpawnColorParameter = "tint",
            }
            .WithBurst(1000)
            .WithGravity()
            .WithCollide(CollisionChannel.WorldDynamic)
            .AddCollisionEvent(10);
        }
    }

    [ClassLibrary]
    public class BlockDebris : ParticleSystemEntry
    {
        public color Tint {get; set;} = Color.White;

        protected override void Initialize()
        {
            base.Initialize();

            Template = ParticleSystem.Library.Get(nameof(BlockDebrisEffect));
            SetColorParameter("tint", Tint);
        }

        public static void Precache()
        {
            ParticleSystem.Library.SetSpecialNamed(nameof(BlockDebrisEffect)); 
            new BlockDebrisEffect();
        }
    }
}