using Physics;

namespace SuicideBarrels
{
    public class Gamemode : BaseGamemode
    {
        public override void Loaded(IGamemodeResources resources)
        {
            Log.Info("SuicideBarrels loaded!");
        }
    }
}