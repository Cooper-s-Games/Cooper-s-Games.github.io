using Physics;

namespace Deathmatch
{
    public class Gamemode : BaseGamemode
    {
        public override void Loaded(IGamemodeResources resources)
        {
            Log.Info("Deathmatch loaded!");
        }
    }
}

