using Physics;
using System;

namespace Deathmatch
{
    enum Round
    {
        WaitingForPlayers,
        RoundStarting,
        RoundActive,
    }

    public struct DeathTarget
    {
        public BaseEntity Entity;
        public string Socket;
        public Vector3 Offset;

        public static readonly DeathTarget NoTarget = new DeathTarget
        {
            Entity = null,
            Socket = string.Empty,
            Offset = Vector3.Zero
        };
    }
}

   [ClassLibrary(Name = "DeathmatchGamemode")]
    class Gamemode : BaseGamemode
    {
        public static Gamemode Current { get; set; }

        [Replicate]
        public Hud Chat { get; private set; }

        [Replicate]
        public Phase Phase { get; set; }

        [Replicate]
        public int Round { get; set; }

        private double _timeToStartRound;
        private double _timeToEndRound;
        private double _roundOverTime;

        public double TimeToEndRound => _timeToEndRound;

        [Replicate]
        public int RoundTimerSeconds { get; set; }

        [ConsoleVariable(Name = "players_needed", Help = "Set players needed to start a round, default 4")]
        public static int PlayersNeeded { get; set; } = 4;

        protected List<Player> _players;
        public int PlayerCount => _players.Count;

        [Replicate]
        public int PlayersWaiting { get; set; } = 0;

        public DeathTarget DeathTarget { get; set; }


        protected override void Initialize()
        {
            base.Initialize();

            Current = this;

            if (Server)
            {
                Chat = World.CreateAndSpawnEntity<Hud>();

                Phase = Phase.WaitingForPlayers;
                Round = 0;
                RoundTimerSeconds = 0;
                PlayersWaiting = 0;

                _players = new List<Player>();
            }

            PreloadAssets();
        }


        protected static void PreloadAssets()
        {
            Sound.Library.Get("hl1/sound/ammopickup1.wav");
            Sound.Library.Get("hl1/sound/gunpickup2.wav");
            Sound.Library.Get("hl1/sound/suitchargeok1.wav");
            Sound.Library.Get("sound/weapon/glock/glock18-1.wav", false);
            Sound.Library.Get("sound/weapon/glock/clipempty_pistol.wav", false);
            SkeletalModel.Library.Get("models/player/mossman.fbx", false);
        }

        protected override void Tick()
        {
            base.Tick();

            if (Authority)
            {
                ServerTick();
            }

            if (Client && Player.Local != null)
            {
                if (Player.Local.Controlling is DeathCamera == false)
                {
                    ClearDeathTarget();
                }
            }
        }

        protected void ServerTick()
        {
            switch (Phase)
            {
                case Phase.WaitingForPlayers:
                    WaitingForPlayers();
                    break;

                case Phase.RoundStarting:
                    RoundStarting();
                    break;

                case Phase.RoundActive:
                    RoundActive();
                    break;

                default:
                    throw new NotSupportedException();
            }
        }

        protected void SwitchPhase(Phase phase)
        {
            if (Phase == phase) return;

            Phase = phase;
        }

        protected void WaitingForPlayers()
        {
            PlayersWaiting = PlayerCount;

            if (PlayerCount < PlayersNeeded)
            {
                return;
            }

            SwitchPhase(Phase.RoundStarting);
        }


        

        protected void RoundActive()
        {
            RoundTimerSeconds = Math.RoundToInt(_timeToEndRound - Time.Now);

            var roundActive = Time.Now < _timeToEndRound;

            BroadcastRoundOver();

            _roundOverTime = Time.Now + RoundOverTime;
            SwitchPhase(Phase.RoundOver);
        }

        public override void LoadMap(string name)
        {
            DefaultPostProcess.MotionBlurAmount = 0;

            base.LoadMap(name);
        }

        public override void OnPlayerJoined(Player player)
        {

            _players.Add(player);

            Chat.BroadcastMessage($"{player.Name} joined");

            if (Authority)
            {
                RespawnPlayer(player);
            }
        }

        public override void OnPlayerLeave(Player player)
        {
            base.OnPlayerLeave(player);

            _players.Remove(player);

            Chat.BroadcastMessage($"{player.Name} left");
        }

        public override void OnPlayerDied(Player player, Controllable controllable)
        {
            if (player == null)
            {
                return;
            }

            Chat.BroadcastMessage($"{player.Name} died");

            if (Authority)
            {
                var position = controllable.Position;
                var eyeAngles = controllable.EyeAngles;

                var deathCamera = new DeathCamera();
                deathCamera.Spawn();
                player.Controlling = deathCamera;

                deathCamera.Position = position;
                deathCamera.Teleport(position);

                deathCamera.EyeAngles = eyeAngles;
                deathCamera.ClientEyeAngles = eyeAngles;

                if (Phase != Phase.RoundOver)
                {
                    RespawnPlayerLater(player, deathCamera, 1.0);
                }
            }
        }

        public override void OnPlayerMessage(string playerName, string message)
        {
            Chat?.Chatbox?.AddMessage(playerName, message, color);
        }

        public override bool AllowPlayerMessage(Player sender, Player receiver, string message)
        {
            return true;
        }

        public override void RespawnPlayer(Player player)
        {
            Log.Assert(Authority);

            if (player.Controlling is DeathCamera deathCamera &&
                deathCamera.IsValid)
            {
                deathCamera.ClientClearTarget();
            }

            player.Controlling?.Destroy();

            var controllable = CreateControllable(player);
            controllable.Spawn();
            player.Controlling = controllable;

            var spawnPoint = FindSpawnPoint();

            if (spawnPoint != null)
            {
                var spawnangles = spawnPoint.Rotation.ToAngles();
                spawnangles = spawnangles.WithZ(0).WithY(spawnangles.Y + 180.0f);

                var eyeAngles = Quaternion.FromAngles(spawnangles);

                var position = spawnPoint.Position + Vector3.Up * heightOffset;
                controllable.Position = position;
                controllable.Teleport(position);
                controllable.ClientLocation = position;
                controllable.EyeAngles = eyeAngles;
                controllable.ClientEyeAngles = eyeAngles;
            }
            else
            {
                Log.Warning("Player can't find spawn! Player: ", player);
            }

            controllable.OnRespawned();
        }

        async void RespawnPlayerLater(Player player, DeathCamera deathCamera, double delay)
        {
            await Delay(TimeSpan.FromSeconds(delay));

            while (deathCamera.IsValid && !deathCamera.WantsToRespawn)
            {
                await Task.Yield();
            }

            if (Phase != Phase.RoundActive)
            {
                return;
            }

            if (deathCamera != null && deathCamera.IsValid)
            {
                deathCamera.ClientClearTarget();
                deathCamera.Destroy();
            }

            RespawnPlayer(player);
        }

        public override void OnLocalInput()
        {
            base.OnLocalInput();
        }

        public void ClearDeathTarget()
        {
            DeathTarget = DeathTarget.NoTarget;
        }

        public void RegisterDeath(Player killer, Player killed)
        {
            Chat?.AddDeathLog(killer.Name, killed.Name);
        }
    }