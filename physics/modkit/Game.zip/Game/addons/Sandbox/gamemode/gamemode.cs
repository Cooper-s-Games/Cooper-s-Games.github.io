using Physics;

namespace Sandbox
{
    public class Gamemode : BaseGamemode
    {
        public override void Loaded(IGamemodeResources resources)
        {
            Log.Info("Sandbox loaded!");
        }
    }
}