using Physics;

namespace Physics.Entities
{
    [ClassLibrary]
    public class Block : BaseModelEntity, ICanBeDamaged, ICanBeRemoved
    {
        public double Force { get; set; }

        [Replicate(OnChange = nameof(OnTintChanged))]
        public Color Tint { get; set; }

        protected Material TintMaterial { get; set; }

        protected override void Initialize()
        {
            base.Initialize();

            if (Authority)
            {
                LinearDamping = 0.0;
                AngularDamping = 0.0;
                EnableGravity = false;
                Collision = true;
                SimulatePhysics = false;
            }

            TintMaterial = new Material { Shader = "Standard" };
            TintMaterial.Set("Color", Tint);
            TintMaterial.Set("Shininess", 1.0);
            TintMaterial.Set("Metallic", 0.0);
            TintMaterial.Set("Specular", 1.0);

            SetMaterial(0, TintMaterial);
        }

        protected override void Tick()
        {
            base.Tick();
        }

        public bool TakeDamage(DamageInfo damage)
        {
            if (Authority)
            {
                BroadcastPopSound();
                Destroy();
            }

            return true;
        }

        [Multicast]
        protected void BroadcastPopSound()
        {
            if (!Client) return;

            PlaySound("Sounds/balloon_pop_cute.wav", 1.0, Random.Double(1.0, 1.3));

            new Effects.BalloonPop
            {
                Position = Position,
                Tint = Tint,
            }
            .Spawn();
        }

        protected void OnTintChanged(Color oldValue, Color newValue)
        {
            if (TintMaterial != null)
            {
                TintMaterial.Set("Color", newValue);
            }
        }

        public bool Remove()
        {
            Destroy();

            return true;
        }
    }
}