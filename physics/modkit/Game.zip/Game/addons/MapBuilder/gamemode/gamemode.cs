using Physics;

namespace MapBuilder
{
    public class Gamemode : BaseGamemode
    {
        public override void Loaded(IGamemodeResources resources)
        {
            Log.Info("MapBuilder loaded");
        }
    }
}