using System;
using System.Collections.Generic;
using System.Linq;

namespace Physics.Import
{
    [ClassLibrary]
    
    public class SourceImport : Importer<bsp>
    {
    public override LoadFileType (string extention) {
        return extention == ".bsp";
    }

    public override bool OnChanged(Map t, string absolute)
    {
    return true;
    }

    public override bsp Import(string AbsoulteName) {
        var map = new BspMap();

        if (bsp.loadFromFile(AbsoulteName) == false) {
            return null;
        }

        return map;
    }
    }
}