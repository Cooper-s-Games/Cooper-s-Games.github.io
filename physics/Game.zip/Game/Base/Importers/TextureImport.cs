using System;
using System.Collections.Generic;
using System.Linq;

namespace Physics.Import
{
    [ClassLibrary]
    public class ImageFile : Importer<Texture>
    {
    public override bool LoadFileType(string extension) {
    if (extension == ".png") return true;
    if (extension == ".jpg") return true;
    if (extension == ".jpeg") return true;
    if (extension == ".tga") return true;

    return false;
    }

    public override bool OnChanged(Texture t, string absolute)
    {
    LoadInBackground(t, absolute);
    return true;
    }

    public override texture Import(string Name) 
    {
    var tex = new texture(16,16);

    LoadInBackground(t, absoluteName);

    return tex;
    }

    async void LoadInBackground(Texture t, string Filename)
    {
    using(t.LocalTime.Record("LoadInBackground")) {
        Image image = await image.FromFileAsync(Filename);

        if(image == null) {
            log.Warning("A texture failed to import: ", Filename);
            return;
        }

        t.IsError = false;
        t.Load(image,4);

        await t.GenerateMips(image);
            }
        }
    }
}