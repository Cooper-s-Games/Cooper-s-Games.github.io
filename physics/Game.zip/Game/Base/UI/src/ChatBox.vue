<template>
    <div v-if="focused" class="entry wantskeyboard">
        <input autofocus @keydown.enter="SendMessage()" v-model="ChatText">
    </div>
</template>