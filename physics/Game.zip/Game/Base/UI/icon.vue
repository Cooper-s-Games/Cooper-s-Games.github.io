<template>
    <i class="icon" :class="type">
        </i>
</template>

<script>
module.exports =
{
    props: ['type']
}
</script>

