if(Input.JustPressed(Button.P))
{
    new MeshEntity
    {
        Position = EyePosition + EyeRotation.Forward * 200.0,
        Model = Model.Library.Get("Sandbox/props/Mossman.fbx")
    }
    .spawn();
}