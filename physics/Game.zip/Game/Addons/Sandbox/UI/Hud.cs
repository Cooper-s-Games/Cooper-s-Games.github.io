using Physics;

namespace Sandbox
{
    [ClassLibrary]
    internal class Hud : EngineHud
    {
        public UI.Chatbox ChatBox {get; protected set;}

        protected override void Initialize()
        {
            base.Initialize();

            if (Client)
            {
                Components.Add(new UI.Crosshair());
                Components.Add(new UI.ChatBox());
            }
        }

        protected override void Tick()
        {
            base.Tick();
        }

        [Multicast]
        public void AddDeathLog(string killer, string killed)
        {
            KillFeed?.Add(killer, killed);
        }

        public void SendChatMessage()
        {
            if(!string.IsNullOrEmpty(ChatText))
                Sandbox.Player.Local?.SendMessage(ChatText);

            ChatText = "";
            Focused = false;
        }
    }
}