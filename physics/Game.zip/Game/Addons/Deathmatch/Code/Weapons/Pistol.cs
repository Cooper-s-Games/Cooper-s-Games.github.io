using Physics;

namespace Deathmatch
{
    [ClassLibrary]
    public class BasePistol : BaseWeapon
    {
        public override string Viewmodel => "Deathmatch/weapons/pistol.fbx";

        public override double FireRate => 0.2;

        public double CurrentAmmo => 7;

        public double BulletDamage => 20;
        public double BulletDistance => 10000; 
        public double BulletForce => 20000; 

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void ShootPrimary(bool pressed)
        {

            if(CurrentAmmo <= 0)
            {
                Reload();
                return;
            }

            base.ShootPrimary(pressed);

            if (!pressed) return;

            if (_lastShootTime > Time.Now - FireRate)
            {
                return;
            }

            _lastShootTime = Time.Now;

            FireBullet(Owner.EyePosition, Owner.EyeRotation.Forward);

            ServerShootPrimary(Owner.EyePosition, Owner.EyeRotation.Forward);
        }

        protected void FireBullet(Vector3 origin, Vector3 direction)
        {
            FireBullet(origin, direction, BulletDamage, BulletDistance, BulletForce);
        }

        [Multicast]
        protected void BroadcastShootPrimary()
        {
            if (Owner == null) return;

            Owner.PlaySoundOnAttachment("deathmatch/sound/weapon/glock/glock18-1.wav", "", Vector3.Zero, 1.0, Random.Double(1.0, 1.1));
            else
            {
                Owner.PlaySoundOnAttachment("deathmatch/sound/weapon/glock/clipempty_pistol.wav", "", Vector3.Zero, 1.0, Random.Double(1.0, 1.1));
            }
        }
    }
}
