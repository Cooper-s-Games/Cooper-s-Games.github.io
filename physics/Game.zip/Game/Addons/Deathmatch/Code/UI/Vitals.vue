<template>
    <div class="vitals">

        <div class="health">
            <icon type="add box"></icon> {{Health}}
        </div>

        <div class="armor" v-bind:class="{none : Armor <= 0}">
            <icon type="security"></icon> {{Armor}}
        </div>
        
</template>

<style lang="less">
    .hud
    {
    position: absolute;
    left: 16px;
    bottom: 16px;
    display: flex;
    }

    .hud div
    {
    line-height: 1;
    font-size: 32px;
    color: #fa0;
    padding: 8px 16px;
    margin-right: 16px;
    display: flex;
    }

    .hud div.disabled
    {
    opacity: 0.3;
    }
</style>

