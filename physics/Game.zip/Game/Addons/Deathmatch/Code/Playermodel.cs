using System;
using Physics;
using System.Threading.Tasks;

namespace Deathmatch
{
    [ClassLibrary]
    public class PlayerModel : SkeletalMeshEntity
    {
        protected override void Initialize()
        {
            base.Initialize();
        }

        public async void DestroyLater(double delay)
        {
            while (UniqueId == Gamemode.Current.DeathTarget.Entity?.UniqueId)
            {
                await Task.Yield();
            }

            await Delay(TimeSpan.FromSeconds(delay));

            Destroy();
        }
    }
}